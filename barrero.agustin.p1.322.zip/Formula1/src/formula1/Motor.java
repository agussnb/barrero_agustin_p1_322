package formula1;

public class Motor extends Pieza implements Ajustador{
    
    private int potenciaMaxima;

    public Motor(String nombre, String ubicacionBox, double temperaturaIdeal, CondicionClimatica condicionClimatica, int potenciaMaxima) {
        super(nombre, ubicacionBox, temperaturaIdeal, condicionClimatica);
        this.potenciaMaxima = potenciaMaxima;
    }
    
    @Override
    public String informacionPiezas(){
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre de la pieza: "+ getNombre()+"\n");
        sb.append("Ubicacion en el box: "+ getUbicacionBox()+"\n");
        sb.append("Temperatura ideal de la pieza: "+getTemperaturaIdeal()+"\n");
        sb.append("Condicion climatica ideal para la pieza: "+getCondicionClimatica()+"\n");
        sb.append("Potencia maxima del motor: "+ potenciaMaxima+"\n");
        return sb.toString();
    }
    
    @Override
    public void ajustar(){
        System.out.println("Ajustando el motor...");
    }
    
    
}
