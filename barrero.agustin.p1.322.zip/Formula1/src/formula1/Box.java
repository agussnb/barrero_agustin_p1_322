package formula1;

import java.util.ArrayList;

public class Box {
    private String nombreEscuderia;
    private ArrayList<Pieza> piezas = new ArrayList<>();

    public Box(String nombreEscuderia) {
        this.nombreEscuderia = nombreEscuderia;
    }
    
    public void agregarPieza(Pieza pieza){
        if (pieza == null){
            throw new IllegalArgumentException("Pieza nula");
        }
        if (piezaEnBox(pieza)){
            throw new PiezaDuplicadaEnBoxException("Ya hay una pieza igual en el box");
        }
        piezas.add(pieza);
        
    }
    
    private boolean piezaEnBox(Pieza pieza){
        if(pieza == null){
            throw new IllegalArgumentException("Pieza nula");
        }
        for(Pieza p : piezas){
            if (p.getNombre().equals(pieza.getNombre()) && 
                    p.getUbicacionBox().equals(pieza.getUbicacionBox())){
                return true;
            }
        }
        return false;
    }
    
    public String mostrarPiezas(){
        StringBuilder sb = new StringBuilder();
        sb.append("Piezas en el box: \n");
        sb.append("\n");
        for (Pieza p : piezas){
            sb.append(p.informacionPiezas());
            sb.append("\n");
        }
        return sb.toString();
    }
    
    public void ajustarPiezas(){
        for (Pieza p : piezas){
            if (p instanceof Ajustador a){
                a.ajustar();
            }else{
                System.out.println("Los neumaticos no se ajustan");
            }
        }
    }
    
    public String buscarPiezasPorCondicion(CondicionClimatica condicion){
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        sb.append("Piezas pensadas para la condicion: "+condicion);
        sb.append("\n");
        for(Pieza p : piezas){
            if (p.getCondicionClimatica() == condicion){
                sb.append("\n");
                sb.append(p.informacionPiezas());
            }else{
                sb.append("No hay piezas de la condicion especificada en el box disponibles");
                break;
            }
        }
        return sb.toString();
    }
    
}
