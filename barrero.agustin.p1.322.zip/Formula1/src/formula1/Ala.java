package formula1;

public class Ala extends Pieza implements Ajustador{
    
    private final int CARGA_AERO_MAX = 10;
    private final int CARGA_AERO_MIN = 1;

    public Ala(String nombre, String ubicacionBox, double temperaturaIdeal, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacionBox, temperaturaIdeal, condicionClimatica);
    }
    
    
    @Override
    public String informacionPiezas(){
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre de la pieza: "+ getNombre()+"\n");
        sb.append("Ubicacion en el box: "+ getUbicacionBox()+"\n");
        sb.append("Temperatura ideal de la pieza: "+getTemperaturaIdeal()+"\n");
        sb.append("Condicion climatica ideal para la pieza: "+getCondicionClimatica()+"\n");
        sb.append("Carga aerodinamica maxima del aleron: "+ CARGA_AERO_MAX+"\n");
        sb.append("Carga aerodinamica minima del aleron: "+ CARGA_AERO_MIN+"\n");
        return sb.toString();
    }
   
    @Override
    public void ajustar(){
        System.out.println("Ajustando el aleron...");
    }
}
