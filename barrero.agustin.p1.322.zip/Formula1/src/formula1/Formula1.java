package formula1;

public class Formula1 {

  
    public static void main(String[] args) {
        Motor m1 = new Motor("PU-016", "Estacion Motor", 80, CondicionClimatica.LLUVIA, 1000);
        //Motor m2 = new Motor("PU-016", "Estacion Motor", 80, CondicionClimatica.LLUVIA, 1000);
        Ala ala1 = new Ala("Aleron delantero", "Estacion alerones", 60, CondicionClimatica.LLUVIA);
        
        Box box = new Box("Mercedes");
        
        Neumatico n1 = new Neumatico(Compuesto.SOFT, "Blando", "Estacion blandos", 80, CondicionClimatica.SECO);
        
        box.agregarPieza(m1);
        //box.agregarPieza(m2);
        box.agregarPieza(ala1);
        box.agregarPieza(n1);
        
        System.out.println(box.mostrarPiezas());
        
        box.ajustarPiezas();
        
        System.out.println(box.buscarPiezasPorCondicion(CondicionClimatica.MIXTO));
    }
    
}
