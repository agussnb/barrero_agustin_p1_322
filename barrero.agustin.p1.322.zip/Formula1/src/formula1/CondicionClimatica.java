package formula1;

public enum CondicionClimatica {
    SECO,
    LLUVIA,
    MIXTO
}
