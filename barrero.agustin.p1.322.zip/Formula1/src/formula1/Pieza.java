package formula1;

public abstract class Pieza {
    private String nombre;
    private String ubicacionBox;
    private double temperaturaIdeal;
    private CondicionClimatica condicionClimatica;

    public Pieza(String nombre, String ubicacionBox, double temperaturaIdeal, CondicionClimatica condicionClimatica) {
        this.nombre = nombre;
        this.ubicacionBox = ubicacionBox;
        this.temperaturaIdeal = temperaturaIdeal;
        this.condicionClimatica = condicionClimatica;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacionBox() {
        return ubicacionBox;
    }

    public double getTemperaturaIdeal() {
        return temperaturaIdeal;
    }

    public CondicionClimatica getCondicionClimatica() {
        return condicionClimatica;
    }
    
    public String informacionPiezas(){
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre de la pieza: "+ nombre+"\n");
        sb.append("Ubicacion en el box: "+ ubicacionBox+"\n");
        sb.append("Temperatura ideal de la pieza: "+temperaturaIdeal+"\n");
        sb.append("Condicion climatica ideal para la pieza: "+condicionClimatica+"\n");
        return sb.toString();
    }
    
    
}
