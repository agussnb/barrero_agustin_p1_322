package formula1;

public class Neumatico extends Pieza{
    
    private Compuesto compuesto;

    public Neumatico(Compuesto compuesto, String nombre, String ubicacionBox, double temperaturaIdeal, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacionBox, temperaturaIdeal, condicionClimatica);
        this.compuesto = compuesto;
    }
    
    @Override
    public String informacionPiezas(){
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre de la pieza: "+ getNombre()+"\n");
        sb.append("Ubicacion en el box: "+ getUbicacionBox()+"\n");
        sb.append("Temperatura ideal de la pieza: "+getTemperaturaIdeal()+"\n");
        sb.append("Condicion climatica ideal para la pieza: "+getCondicionClimatica()+"\n");
        sb.append("Tipo de compuesto: "+compuesto+"\n");
        return sb.toString();
    }
    
}
