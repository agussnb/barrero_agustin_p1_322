package formula1;

public class PiezaDuplicadaEnBoxException extends RuntimeException{

    public PiezaDuplicadaEnBoxException(String message) {
        super(message);
    }
    
}
